<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');


$route['main/login'] = "main/login";
$route['main/registrar'] = "main/registrar";

$route['default_controller'] = "main";
$route['404_override'] = 'no_encontrado';

/* End of file routes.php */
/* Location: ./application/config/routes.php */
