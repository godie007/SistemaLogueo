
<div class="container-fluid">
    <div class="row-fluid">
        <div class="span3">
            <div class="well sidebar-nav">
                <ul class="nav nav-list">
                    <li class="nav-header">espacio</li>
                    <li class="active"><a href="#">Loguear</a></li>
                    <form class="well form-inline" method="POST" action="http://localhost/index.php?/main/login">
                        <div class="control-group">
                            <label class="control-label" for="input01">Nombre</label>
                            <div class="controls">
                                <input type="text" name="usuario" class="input-size" id="input01">
                            </div>
                            <label class="control-label" for="input01">Contrasena</label>
                            <div class="controls">
                                <input type="password" name="contrasena" class="input-size" placeholder="Password">
                            </div>
                            <button class="btn btn-success" type="submit">iniciar</button>
                        </div>
                    </form>

                    <li><a href="#">Link2</a></li>

                    </button>
                    <li><a href="#">Link3</a></li>

                    </button>
                    <li><a href="#">Link4</a></li>

                    </button>
                </ul>
            </div><!--/.well -->
        </div><!--/span-->
        <div class="span9">
            <div class="hero-unit">
                <form class="form-horizontal" method="POST" action="http://localhost/index.php?/main/registrar">
                    <fieldset>
                        <div class="control-group">
                            <label class="control-label" for="input01">Nombre</label>
                            <div class="controls">
                                <input type="text" name="nombre" class="input-size" id="input01">
                            </div>
                            <label class="control-label" for="input01">Contrasena</label>
                            <div class="controls">
                                <input type="password" name="passworda" class="input-size" placeholder="Password">
                            </div>
                            <label class="control-label" for="input01">Correo</label>
                            <div class="controls">
                                <input type="text" name="correo" class="input-xlarge" placeholder="Email">
                            </div>
                            <button class="btn btn-success" type="submit">Registrarse</button>
                        </div>
                    </fieldset>
                </form>
                
                <script type="text/javascript">
                    // declarando variables Globales
                    var valor1 = 0; 
                    var valor2 = 0; 
                    var operacion
                    // funcion que agrega al textbox  los numeros que vamos presionando
                    function estapresionado(valor) { 
                        if (document.getElementById("txtmostrar").value == "0" || valor1 == 0) { 
                            valor1 = valor; 
                        } else 
                        { 
                            valor1 += valor; 
                        } 
                        document.getElementById("txtmostrar").value = valor1;
                    }
                    // función que  asigna el operador seleccionado
                    function asignaroperador(codigo) { 
                        print(valor1);          
                        if (valor1 == 0) { 
                            resultado = parseInt(document.getElementById("txtmostrar").value); 
                        } 
                        valor2 = parseInt(valor1); 
                        valor1 = 0; 
                        operacion = codigo; 
                        printsimbolo(operacion); // imprimiendo simbolo en lblresumen
                    }
                    
                    // imprimiendo los numeros en el label para saber que operaciones hemos hecho 
                    function print(s) { 
                        document.getElementById("lblresumen").value += s; 
                    }
                    // imprimiendo el simbolo de suma, resta , multiplicacion y divicion 
                    function printsimbolo() { 
                        switch (parseInt(operacion)) { 
                            case 1: 
                                document.getElementById("lblresumen").value += "+"; 
                                break; 
                            case 2: 
                                document.getElementById("lblresumen").value += "-"; 
                                break; 
                            case 3: 
                                document.getElementById("lblresumen").value += "*"; 
                                break; 
                            case 4: 
                                document.getElementById("lblresumen").value += "/"; 
                                break;
                        }
                    } 
                    // funcion que nos facilitara el resultado cuando presionamos el boton igual 
                    function resultado() 
                    { 
                        print(valor1); 
                        valor1= parseInt(valor1); 
                        switch (parseInt(operacion)) { 
                            case 1: 
                                valor1 += valor2; 
                                break; 
                            case 2: 
                                valor1 = valor2 – valor1; 
                                break; 
                            case 3: 
                                valor1 *= valor2; 
                                break; 
                            case 4: 
                                valor1 = valor2 / valor1; 
                                break;
                        } 
                        document.getElementById("lblresumen").value += "="; 
                        document.getElementById("txtmostrar").value = valor1; 
                        valor2 = parseInt(valor1); // valor 2 toma el valor de valor 1 
                    }
                </script>

                <div id="wrap">
                    <h1>Bienvenido</h1>
                    <a href="" title="Download Me!" id="btn-wrap">
                        <span class="title">Descargar</span>

                        <div id="info">
                            <p>
                                <strong>Version 1.1</strong>
                                <span>99 tb</span>
                            </p>
                        </div>
                    </a>
                </div>

            </div>

        </div><!--/row-->
    </div><!--/span-->
</div><!--/row-->

<footer>
    <p>&copy; Godie007 2012</p>
</footer>

</div><!--/.fluid-container-->

<!-- Le javascript
================================================== -->
<!-- Placed at the end of the document so the pages load faster -->
<script src="../js/jquery.js"></script>
<script src="../js/bootstrap-transition.js"></script>
<script src="../js/bootstrap-alert.js"></script>
<script src="../js/bootstrap-modal.js"></script>
<script src="../js/bootstrap-dropdown.js"></script>
<script src="../js/bootstrap-scrollspy.js"></script>
<script src="../js/bootstrap-tab.js"></script>
<script src="../js/bootstrap-tooltip.js"></script>
<script src="../js/bootstrap-popover.js"></script>
<script src="../js/bootstrap-button.js"></script>
<script src="../js/bootstrap-collapse.js"></script>
<script src="../js/bootstrap-carousel.js"></script>
<script src="../js/bootstrap-typeahead.js"></script>

</body>
</html>