<?php

class Main extends CI_Controller {

    public function index() {
        $data['main_content'] = 'panelPrincipal';
        $data['title'] = 'Godie007';
        $data['usuario'] = 'Godie007';
        $this->load->view('includes/template', $data);
    }

    public function registrar() {
        $data = $this->input->post();
        $this->load->model('usuario_model');
        $this->usuario_model->registrarUsuario($data['nombre'], $data['correo'], $data['passworda']);
        $this->load->view('entrar');
    }

    function validar() {
        $this->load->view('loginVista');
    }
    function logout()
  {
//    $this->session->unset_userdata('logged_in');
//    session_destroy();
//    redirect('main', 'refresh');
         $this->load->view('SignOut');
  }

}