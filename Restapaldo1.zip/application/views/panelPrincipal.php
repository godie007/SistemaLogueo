<div class="navbar navbar-fixed-top">
    <div class="navbar-inner">
        <div class="container-fluid">
            <a class="btn btn-navbar" data-toggle="collapse" data-target=".nav-collapse">
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
            </a>
            <a class="brand" href="#">Project Godie007</a>
            <div class="btn-group pull-right">
                <a class="btn dropdown-toggle" data-toggle="dropdown" href="#">
                    <i class="icon-user"></i> <? echo $usuario ?>
                    <span class="caret"></span>
                </a>
                <ul class="dropdown-menu">
                    <li><a href="#">Profile</a></li>
                    <li class="divider"></li>
                    <li><a href="http://localhost/index.php?/main/logout">SignOut</a></li>

                </ul>
            </div>
            <button class="btn btn-inverse" type="submit">Inicio</button>
            <input type="text" data-provide="typeahead">
            <button class="btn btn-success" type="submit">Buscar</button>
            <button class="btn btn-danger" type="submit">Salir</button>
            <div class="nav-collapse">
                <ul class="nav">


                </ul>
            </div><!--/.nav-collapse -->

        </div>
    </div><!--/span-->
</div>
</div>
