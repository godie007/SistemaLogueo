<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
    <head>
        <title>Salida...</title>
           <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta name="description" content="">
        <meta name="author" content="">

        <!-- Le styles -->
        <link href="../css/bootstrap.css" rel="stylesheet">
         <link href="../css/bootstrap-responsive.css" rel="stylesheet">

        <!-- Le HTML5 shim, for IE6-8 support of HTML5 elements -->
        <!--[if lt IE 9]>
          <script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
        <![endif]-->

        <!-- Le fav and touch icons -->
        <link rel="shortcut icon" href="../assets/ico/favicon.ico">
        <link rel="apple-touch-icon-precomposed" sizes="144x144" href="../ico/apple-touch-icon-144-precomposed.png">
        <link rel="apple-touch-icon-precomposed" sizes="114x114" href="../ico/apple-touch-icon-114-precomposed.png">
        <link rel="apple-touch-icon-precomposed" sizes="72x72" href="../ico/apple-touch-icon-72-precomposed.png">
        <link rel="apple-touch-icon-precomposed" href="../ico/apple-touch-icon-57-precomposed.png">
        <script>var _gaq=[['_setAccount','UA-20257902-1'],['_trackPageview']];(function(d,t){ var g=d.createElement(t),s=d.getElementsByTagName(t)[0]; g.async=1;g.src='//www.google-analytics.com/ga.js';s.parentNode.insertBefore(g,s)}(document,'script'))</script>
        <script src="./audiojs/audio.min.js"></script>
        <link rel="stylesheet" href="./includes/index.css" media="screen">
        <script>
            audiojs.events.ready(function() {
                audiojs.createAll();
            });
        </script>
        <meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
        <link rel="stylesheet" href="http://www.blogdephp.com/script/php-login.css" type="text/css" media="screen">
        <!--<link rel="stylesheet" href="../../php-login.css" type="text/css" media="screen">-->
    </head>
    <body>

    <header>
        <h1>Us Ha salido..</h1>
    </header>
    <audio src="audiojs/esperanza.mp3" preload="auto"></audio>
    <h3>Gracias por usar la pagina</h3>
    <ol>
        <li>
            <p>si... <code>desea volver a Incio presione el boton:</code>, volver....</p>
        </li>
        <form class="well form-inline" method="POST" action="http://localhost/index.php?/main">
            <button class="btn btn-primary" type="submit">Volver a pagina Principal</button>
        </form>
    </ol>
    <footer>
        <p>Godie007</a>, 2012.</p>

    </footer>
    <script src="../js/bootstrap-button.js"></script>
</body>
</html>