<div class="navbar navbar-fixed-top">
    <div class="navbar-inner">
        <div class="container-fluid">
            <a class="btn btn-navbar" data-toggle="collapse" data-target=".nav-collapse">
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
            </a>
            <a class="brand" href="#">Project Godie007</a>
            <div class="btn-group pull-right">
                <a class="btn dropdown-toggle" data-toggle="dropdown" href="#">
                    <i class="icon-user"></i> <? echo $usuario ?>
                    <span class="caret"></span>
                </a>
                <ul class="dropdown-menu">
                    <li><a href="#">Profile</a></li>
                    <li class="divider"></li>
                    <li><a href="http://localhost/index.php?/main/logout">SignOut</a></li>

                </ul>
            </div>
            <input type="text" data-provide="typeahead">
            <div class="nav-collapse">
                <ul class="nav">


                </ul>
            </div><!--/.nav-collapse -->

        </div>
    </div><!--/span-->
</div>
</div>
